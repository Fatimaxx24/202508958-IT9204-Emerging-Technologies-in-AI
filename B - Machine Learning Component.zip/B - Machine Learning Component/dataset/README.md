# Dataset — Phishing Email Detection

## Download Instructions
1. Go to: https://www.kaggle.com/datasets/subhajournal/phishingemails
2. Click Download (requires free Kaggle account)
3. Extract and place Phishing_Email.csv in this folder

## Dataset Facts
| Property | Value |
| Source | Kaggle / Subha Journal |
| Rows | 18,650 emails |
| Phishing | 7,328 (39.3%) |
| Safe | 11,322 (60.7%) |
| Features | Email Text, Email Type |
| Target | Email Type (Phishing Email / Safe Email) |