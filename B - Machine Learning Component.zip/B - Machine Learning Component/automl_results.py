"""
Part B - Machine Learning Component
AutoML Results Summary
AutoML Job: fatema-hasan-automl-job
Best Model: StandardScalerWrapper, LogisticRegression
AUC: 0.99683
"""

# AutoML Results - documented from Azure ML Studio
automl_results = {
    "job_name": "fatema-hasan-automl-job",
    "experiment": "fatema-hasan-automl",
    "dataset": "phishing-email-dataset:1",
    "duration": "6h 25m",
    "status": "Completed",
    "best_model": {
        "name": "fatema-hasan-phishing-automl-best-model",
        "algorithm": "StandardScalerWrapper, LogisticRegression",
        "auc_weighted": 0.99683,
        "sampling": "100%",
        "registered_version": 1
    },
    "all_models_tried": [
        {"algorithm": "StandardScalerWrapper, LogisticRegression", "auc": 0.99683},
        {"algorithm": "MaxAbsScaler, LightGBM",                   "auc": 0.99659},
        {"algorithm": "MaxAbsScaler, XGBoostClassifier",          "auc": 0.99648},
        {"algorithm": "SparseNormalizer, XGBoostClassifier",      "auc": 0.99635},
        {"algorithm": "StandardScalerWrapper, LightGBM",          "auc": 0.99456},
        {"algorithm": "StandardScalerWrapper, LinearSVM",         "auc": 0.99392},
        {"algorithm": "TruncatedSVDWrapper, XGBoostClassifier",   "auc": 0.99129},
        {"algorithm": "StandardScalerWrapper, RandomForest",      "auc": 0.99080},
    ],
    "comparison_with_manual": {
        "manual_notebook": {
            "algorithm": "LogisticRegression (TF-IDF + engineered features)",
            "accuracy": 0.9640,
            "auc_roc": 0.9936,
            "training_time": "~2 minutes"
        },
        "automl_best": {
            "algorithm": "StandardScalerWrapper, LogisticRegression",
            "auc_weighted": 0.99683,
            "training_time": "6h 25m (tried 8+ algorithms)"
        },
        "conclusion": (
            "Both approaches selected Logistic Regression as the best algorithm, "
            "validating our manual model selection. AutoML achieved marginally higher "
            "AUC (0.99683 vs 0.9936) by exploring hyperparameter space automatically. "
            "The manual model is used in production due to its faster inference time "
            "and custom feature engineering pipeline."
        )
    }
}

if __name__ == "__main__":
    import json
    print("=" * 65)
    print("  AutoML Results Summary")
    print("  IT9204 | Fatema Hasan (202508958)")
    print("=" * 65)

    print(f"\nBest Model: {automl_results['best_model']['algorithm']}")
    print(f"AUC Weighted: {automl_results['best_model']['auc_weighted']}")
    print(f"Duration: {automl_results['duration']}")

    print(f"\n── All Models Tried ──────────────────────────────────")
    for i, m in enumerate(automl_results["all_models_tried"], 1):
        print(f"  {i}. {m['algorithm']:<45} AUC: {m['auc']}")

    print(f"\n── Comparison: Manual vs AutoML ──────────────────────")
    manual = automl_results["comparison_with_manual"]["manual_notebook"]
    automl = automl_results["comparison_with_manual"]["automl_best"]
    print(f"  Manual:  {manual['algorithm']}")
    print(f"           Accuracy={manual['accuracy']} | AUC={manual['auc_roc']}")
    print(f"  AutoML:  {automl['algorithm']}")
    print(f"           AUC={automl['auc_weighted']}")
    print(f"\n  Conclusion: {automl_results['comparison_with_manual']['conclusion']}")

    # Save to JSON
    with open("automl_results.json", "w") as f:
        json.dump(automl_results, f, indent=2)
    print(f"\n[Saved to automl_results.json]")