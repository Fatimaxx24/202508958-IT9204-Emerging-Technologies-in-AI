import json
import joblib
import re
import os
import pandas as pd
from scipy.sparse import hstack

def init():
    global model, tfidf, scaler
    # AZUREML_MODEL_DIR points to: /var/azureml-app/azureml-models/phishing-email-classifier/1
    model_dir = os.getenv("AZUREML_MODEL_DIR", ".")
    # List directory contents for debugging
    print("AZUREML_MODEL_DIR:", model_dir)
    for root, dirs, files in os.walk(model_dir):
        for f in files:
            print("  Found:", os.path.join(root, f))
    
    # Try to find pkl files anywhere under model_dir
    def find_file(name):
        for root, dirs, files in os.walk(model_dir):
            if name in files:
                return os.path.join(root, name)
        raise FileNotFoundError(f"{name} not found under {model_dir}")
    
    model  = joblib.load(find_file("phishing_model.pkl"))
    tfidf  = joblib.load(find_file("tfidf_vectorizer.pkl"))
    scaler = joblib.load(find_file("scaler.pkl"))
    print("All models loaded successfully!")

def preprocess_email(text):
    if not text:
        return ""
    text = str(text).lower()
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'https?://\S+', ' URL_PRESENT ', text)
    text = re.sub(r'\S+@\S+', ' EMAIL_PRESENT ', text)
    text = re.sub(r'[^a-z0-9\s]', ' ', text)
    return text[:2000].strip()

def extract_features(text):
    o = str(text).lower() if text else ""
    return {
        'has_url': int(bool(re.search(r'https?://', o))),
        'url_count': len(re.findall(r'https?://', o)),
        'has_urgent_words': int(bool(re.search(r'urgent|immediately|verify|suspend|click|confirm|update|limited|expires|winner|prize|free', o))),
        'has_financial_words': int(bool(re.search(r'bank|account|password|credit card|ssn|paypal|bitcoin|wire transfer', o))),
        'exclamation_count': o.count('!'),
        'dollar_count': o.count('$'),
        'text_length': min(len(o), 20000),
        'caps_ratio': sum(1 for c in str(text) if c.isupper()) / max(len(str(text)), 1),
        'has_phone': int(bool(re.search(r'\d{3}.\d{3}.\d{4}', o))),
        'has_dear': int(bool(re.search(r'dear', o))),
    }

def run(raw_data):
    try:
        data  = json.loads(raw_data)
        email = data.get("email_text", "")
        clean = preprocess_email(email)
        tfidf_feat = tfidf.transform([clean])
        eng_feat   = scaler.transform(pd.DataFrame([extract_features(email)]))
        combined   = hstack([tfidf_feat, eng_feat])
        pred = model.predict(combined)[0]
        prob = model.predict_proba(combined)[0][1]
        return json.dumps({
            "prediction": int(pred),
            "label": "Phishing Email" if pred == 1 else "Safe Email",
            "phishing_probability": round(float(prob), 4),
            "confidence": round(float(max(prob, 1 - prob)), 4)
        })
    except Exception as e:
        return json.dumps({"error": str(e)})
