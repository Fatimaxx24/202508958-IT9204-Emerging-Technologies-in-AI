"""
Part E - System Integration
End-to-end integration script that ties all components together.
"""

import json
import sys
import argparse
from pathlib import Path
from datetime import datetime

BASE = Path(__file__).parent.parent
sys.path.insert(0, str(BASE / "C - Agent System"))
sys.path.insert(0, str(BASE / "D - Decision and Reasoning Layer"))

from agent import answer_query
from decision_logic import classify_query, DECISION_DIAGRAM

RESULTS_DIR = BASE / "F - Evaluation and Analysis"
RESULTS_DIR.mkdir(exist_ok=True)

# ── Demo queries covering all 4 paths ────────────────────────────────────────

DEMO_QUERIES = [
    {
        "id": "Q1",
        "path": "A (Classification)",
        "query": (
            "URGENT! Your PayPal account has been suspended due to suspicious activity. "
            "Click here immediately to verify: http://paypal-secure-verify.xyz/login. "
            "Failure to verify within 24 hours will result in permanent closure. Dear Customer, act now!"
        )
    },
    {
        "id": "Q2",
        "path": "B (Guidance)",
        "query": "What should I do if I accidentally clicked a link in a phishing email?"
    },
    {
        "id": "Q3",
        "path": "A (Classification - Safe)",
        "query": (
            "Hi John, I hope you are doing well. Please find attached the Q1 2024 financial "
            "report as discussed in our meeting last Tuesday. Let me know if you have any questions. "
            "Best regards, Sarah from Finance."
        )
    },
    {
        "id": "Q4",
        "path": "B (Guidance)",
        "query": "What are the main signs that an email is a phishing attempt?"
    },
]


def run_query(query_text: str, label: str = "") -> dict:
    """Run one query through the full pipeline and return structured result."""
    print(f"\n{'='*65}")
    print(f"  {label}")
    print(f"{'='*65}")
    print(f"Query: {query_text[:100]}...\n" if len(query_text) > 100 else f"Query: {query_text}\n")

    # Step 1: Deterministic routing
    routing = classify_query(query_text)
    print(f"[Router] Path {routing.path.value} — {routing.path.name}")
    print(f"[Router] {routing.reason}\n")

    # Step 2: Agent execution
    result = answer_query(query_text)

    print(f"\n── Agent Response ──────────────────────────────────────")
    print(result["response"])

    if result["tools_called"]:
        tool_names = [t["tool"] for t in result["tools_called"]]
        print(f"\n[Tools used: {', '.join(tool_names)}]")

    return {
        "label":          label,
        "query":          query_text,
        "routing_path":   routing.path.name,
        "routing_reason": routing.reason,
        "tools_called":   [t["tool"] for t in result["tools_called"]],
        "response":       result["response"],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--query", type=str, help="Run a custom query")
    args = parser.parse_args()

    print("\n" + "="*65)
    print("  Phishing Email Detection and Advisory Assistant")
    print("  IT9204 Individual Project | Fatema Hasan (202508958)")
    print("="*65)
    print(DECISION_DIAGRAM)

    results = []

    if args.query:
        results.append(run_query(args.query, label="Custom Query"))
    else:
        for demo in DEMO_QUERIES:
            results.append(run_query(demo["query"], label=f"{demo['id']} — {demo['path']}"))

    # Save results to F - Evaluation and Analysis
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = RESULTS_DIR / f"integration_run_{timestamp}.json"
    with open(out_path, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\n[Results saved to: {out_path}]")


if __name__ == "__main__":
    main()