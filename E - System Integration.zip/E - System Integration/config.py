# E - System Integration/config.py
import os
from dotenv import load_dotenv

load_dotenv()

# Azure OpenAI
AZURE_OPENAI_ENDPOINT    = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_OPENAI_API_KEY     = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview")
AZURE_OPENAI_DEPLOYMENT  = os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o")

# Azure AI Search (RAG)
AZURE_SEARCH_ENDPOINT = os.getenv("AZURE_SEARCH_ENDPOINT")
AZURE_SEARCH_KEY      = os.getenv("AZURE_SEARCH_KEY")
AZURE_SEARCH_INDEX    = os.getenv("AZURE_SEARCH_INDEX", "phishing-knowledge-base")

# Azure ML Endpoint (ML Model)
AZURE_ML_ENDPOINT_URL = os.getenv("AZURE_ML_ENDPOINT_URL")
AZURE_ML_ENDPOINT_KEY = os.getenv("AZURE_ML_ENDPOINT_KEY")

# Thresholds for decision logic
HIGH_RISK_THRESHOLD   = 0.70
MEDIUM_RISK_THRESHOLD = 0.40

# RAG settings
CHUNK_SIZE    = 300
CHUNK_OVERLAP = 50
TOP_K_RESULTS = 3
EMBED_DIMENSIONS = 1536
AZURE_EMBED_DEPLOYMENT = "text-embedding-3-small"