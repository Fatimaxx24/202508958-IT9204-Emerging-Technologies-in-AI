"""
Part C - Agent System | Part D - Decision & Reasoning Layer
Phishing Email Detection and Advisory Assistant
Azure OpenAI agent with function calling (tool use).
"""

import json
import sys
from pathlib import Path

from openai import AzureOpenAI

sys.path.insert(0, str(Path(__file__).parent.parent / "E - System Integration"))
from config import (
    AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_API_VERSION, AZURE_OPENAI_DEPLOYMENT,
    HIGH_RISK_THRESHOLD, MEDIUM_RISK_THRESHOLD,
)
from tools import TOOL_SCHEMAS, dispatch_tool

# ── System prompt ─────────────────────────────────────────────────────────────

SYSTEM_PROMPT = f"""You are a Phishing Email Detection and Advisory Assistant.
Your users are security analysts, IT staff, and regular employees who need help
identifying and responding to phishing emails.

You have access to three tools:
1. predict_phishing         — calls the ML model to classify an email as phishing or safe
2. retrieve_guidelines      — searches the cybersecurity knowledge base for relevant guidance
3. analyze_email_features   — extracts and explains phishing indicators from email text

## Decision Rules (follow exactly):

**Path A — Email Classification Request**
Trigger: User provides email content and asks if it is phishing.
Action:
  1. Call analyze_email_features to extract indicators.
  2. Call predict_phishing to get the ML probability score.
  3. If phishing_probability >= {HIGH_RISK_THRESHOLD}, ALSO call retrieve_guidelines
     for relevant response procedures.
  4. Combine all outputs into a clear verdict with explanation.

**Path B — Guidance / Policy Question**
Trigger: User asks "what should I do", "how do I respond", "what are the signs".
Action: Call retrieve_guidelines only. Do NOT call the ML model.

**Path C — Explanation Request**
Trigger: User asks "why is this suspicious", "explain the indicators", "what makes this phishing".
Action:
  1. Call analyze_email_features to get detailed breakdown.
  2. Call retrieve_guidelines to ground the explanation in security guidelines.

**Path D — Ambiguous Query**
Trigger: Query does not clearly fit A, B, or C.
Action: Call retrieve_guidelines as safe default.

## Response Rules:
- Always state the ML probability and risk level clearly when the model is used.
- Always cite the source document when referencing guidelines (e.g. [cisa_phishing_guidance]).
- Never fabricate security advice — all recommendations must come from retrieved documents.
- Structure your response with clear sections: Verdict, Indicators, Recommended Actions.
- Remind users that this is a decision-support tool — human judgment is always required.
- Be concise and professional.
"""

# ── Client ────────────────────────────────────────────────────────────────────

client = AzureOpenAI(
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
    api_key=AZURE_OPENAI_API_KEY,
    api_version=AZURE_OPENAI_API_VERSION,
)

# ── Agent loop ────────────────────────────────────────────────────────────────

def run_agent(user_query: str, conversation_history: list = None) -> dict:
    """
    Run one turn of the agent.
    Returns dict with: response, tools_called, messages.
    """
    messages = (conversation_history or []) + [
        {"role": "user", "content": user_query}
    ]
    if not conversation_history:
        messages.insert(0, {"role": "system", "content": SYSTEM_PROMPT})

    tools_called = []

# Agentic loop
    while True:
        try:
            response = client.chat.completions.create(
                model=AZURE_OPENAI_DEPLOYMENT,
                messages=messages,
                tools=TOOL_SCHEMAS,
                tool_choice="auto",
                temperature=0.1,
                max_tokens=2048,
            )
        except Exception as e:
            error_msg = str(e)
            # If content filter, try without tools as plain analysis
            if "content_filter" in error_msg or "400" in error_msg:
                try:
                    # Retry with a safer framing
                    safe_messages = [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": f"Analyze this text for phishing indicators and classify it: {messages[-1]['content'][:500]}"}
                    ]
                    response = client.chat.completions.create(
                        model=AZURE_OPENAI_DEPLOYMENT,
                        messages=safe_messages,
                        tools=TOOL_SCHEMAS,
                        tool_choice="auto",
                        temperature=0.1,
                        max_tokens=2048,
                    )
                except Exception as e2:
                    return {
                        "response": f"Content filter triggered. Manual review recommended for this email. Error: {str(e2)}",
                        "tools_called": tools_called,
                        "messages": messages,
                    }
            else:
                return {
                    "response": f"Error: {error_msg}",
                    "tools_called": tools_called,
                    "messages": messages,
                }

        message = response.choices[0].message
        messages.append(message.model_dump(exclude_unset=True))

        # No tool calls = final answer
        if not message.tool_calls:
            return {
                "response":     message.content,
                "tools_called": tools_called,
                "messages":     messages,
            }

        # Execute tool calls
        for tool_call in message.tool_calls:
            name   = tool_call.function.name
            args   = json.loads(tool_call.function.arguments)
            print(f"  [Tool] Calling: {name}")
            result = dispatch_tool(name, args)
            tools_called.append({
                "tool":   name,
                "args":   args,
                "result": json.loads(result)
            })
            messages.append({
                "role":         "tool",
                "tool_call_id": tool_call.id,
                "content":      result,
            })


def answer_query(query: str) -> dict:
    """Stateless single-query interface."""
    return run_agent(query, conversation_history=None)


# ── Interactive mode ──────────────────────────────────────────────────────────

def run_conversation():
    """Interactive multi-turn conversation loop."""
    print("=" * 65)
    print("  Phishing Email Detection and Advisory Assistant")
    print("  IT9204 Individual Project | Fatema Hasan (202508958)")
    print("=" * 65)
    print("Paste an email or ask a question. Type 'exit' to quit.\n")

    history = [{"role": "system", "content": SYSTEM_PROMPT}]

    while True:
        user_input = input("You: ").strip()
        if user_input.lower() in ("exit", "quit", "q"):
            print("Session ended.")
            break
        if not user_input:
            continue

        print("\n[Agent reasoning...]")
        result = run_agent(user_input, history)

        print(f"\nAssistant:\n{result['response']}")
        if result["tools_called"]:
            tool_names = [t["tool"] for t in result["tools_called"]]
            print(f"\n[Tools used: {', '.join(tool_names)}]")
        print()

        history = result["messages"]


if __name__ == "__main__":
    run_conversation()