"""
Part C - Agent System: Tool Implementations
Three tools the agent can call:
  1. predict_phishing      — calls Azure ML endpoint
  2. retrieve_guidelines   — calls Azure AI Search (RAG)
  3. analyze_email_features — extracts phishing signals from email
"""

import json
import re
import requests
import sys
from pathlib import Path

# Add E - System Integration to path for config
sys.path.insert(0, str(Path(__file__).parent.parent / "E - System Integration"))
sys.path.insert(0, str(Path(__file__).parent.parent / "A - Data and Knowledge Layer"))

from config import (
    AZURE_ML_ENDPOINT_URL, AZURE_ML_ENDPOINT_KEY,
    HIGH_RISK_THRESHOLD, MEDIUM_RISK_THRESHOLD,
)
from rag_pipeline import retrieve_documents, format_context


# ── Tool 1: predict_phishing ──────────────────────────────────────────────────

PREDICT_PHISHING_SCHEMA = {
    "name": "predict_phishing",
    "description": (
        "Call the deployed Azure ML model to predict whether an email is phishing or safe. "
        "Returns a probability score (0-1), predicted label, and risk level. "
        "Use this when the user provides email content and wants to know if it is phishing."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "email_text": {
                "type": "string",
                "description": "The full text content of the email to analyze."
            }
        },
        "required": ["email_text"]
    }
}


def predict_phishing(email_text: str) -> dict:
    """Call the Azure ML endpoint to classify the email."""
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {AZURE_ML_ENDPOINT_KEY}"
    }
    payload = json.dumps({"email_text": email_text})

    try:
        response = requests.post(
            AZURE_ML_ENDPOINT_URL,
            data=payload,
            headers=headers,
            timeout=30
        )
        response.raise_for_status()
        # Response is double-encoded JSON
        result = json.loads(response.text)
        if isinstance(result, str):
            result = json.loads(result)

        prob = result.get("phishing_probability", 0.0)
        risk_level = (
            "critical" if prob >= 0.85 else
            "high"     if prob >= HIGH_RISK_THRESHOLD else
            "medium"   if prob >= MEDIUM_RISK_THRESHOLD else
            "low"
        )
        return {
            "prediction":           result.get("prediction", 0),
            "label":                result.get("label", "Unknown"),
            "phishing_probability": prob,
            "confidence":           result.get("confidence", 0.0),
            "risk_level":           risk_level,
            "source":               "Azure ML Endpoint (phishing-online-endpoint)"
        }
    except Exception as e:
        return {"error": str(e), "source": "Azure ML Endpoint"}


# ── Tool 2: retrieve_guidelines ──────────────────────────────────────────────

RETRIEVE_GUIDELINES_SCHEMA = {
    "name": "retrieve_guidelines",
    "description": (
        "Search the phishing knowledge base and return relevant cybersecurity guidelines, "
        "best practices, and incident response procedures. "
        "Use this when the user asks what action to take, what the indicators are, "
        "or wants an explanation grounded in security guidelines. "
        "Always use this after predict_phishing when risk is high or critical."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Natural language query for the knowledge base."
            },
            "top_k": {
                "type": "integer",
                "description": "Number of chunks to retrieve (default 3, max 5).",
                "default": 3
            }
        },
        "required": ["query"]
    }
}


def retrieve_guidelines(query: str, top_k: int = 3) -> dict:
    """Retrieve relevant phishing guidelines from Azure AI Search."""
    top_k   = min(top_k, 5)
    results = retrieve_documents(query=query, top_k=top_k)
    return {
        "context":     format_context(results),
        "sources":     [r["source"] for r in results],
        "chunk_count": len(results)
    }


# ── Tool 3: analyze_email_features ───────────────────────────────────────────

ANALYZE_EMAIL_SCHEMA = {
    "name": "analyze_email_features",
    "description": (
        "Extract and analyze phishing signal features from an email text. "
        "Returns a structured breakdown of suspicious indicators found in the email "
        "such as urgency language, suspicious URLs, financial keywords, and more. "
        "Use this to provide a detailed explanation of WHY an email is suspicious."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "email_text": {
                "type": "string",
                "description": "The full text content of the email to analyze."
            }
        },
        "required": ["email_text"]
    }
}


def analyze_email_features(email_text: str) -> dict:
    """Extract phishing signal features from email text."""
    text = str(email_text).lower() if email_text else ""

    # Extract features
    urls = re.findall(r'https?://\S+', text)
    urgent_words = re.findall(
        r'\b(urgent|immediately|verify|suspend|click|confirm|update|'
        r'limited|expires|act now|winner|prize|free|alert|warning)\b', text)
    financial_words = re.findall(
        r'\b(bank|account|password|credit card|ssn|paypal|'
        r'bitcoin|wire transfer|payment|invoice)\b', text)
    exclamations = text.count('!')
    dollar_signs = text.count('$')
    has_dear     = bool(re.search(r'\bdear\b', text))
    has_phone    = bool(re.search(r'\b\d{3}[-.]\d{3}[-.]\d{4}\b', text))
    caps_ratio   = sum(1 for c in email_text if c.isupper()) / max(len(email_text), 1)
    word_count   = len(text.split())

    # Build risk indicators list
    indicators = []
    if urls:
        indicators.append(f"Contains {len(urls)} URL(s): {urls[:3]}")
    if urgent_words:
        indicators.append(f"Urgency language detected: {list(set(urgent_words))}")
    if financial_words:
        indicators.append(f"Financial keywords detected: {list(set(financial_words))}")
    if exclamations > 2:
        indicators.append(f"Excessive exclamation marks: {exclamations}")
    if dollar_signs > 0:
        indicators.append(f"Dollar sign(s) found: {dollar_signs}")
    if has_dear:
        indicators.append("Generic greeting ('Dear') detected — possible mass phishing")
    if has_phone:
        indicators.append("Phone number pattern detected")
    if caps_ratio > 0.15:
        indicators.append(f"High capitalization ratio: {caps_ratio:.1%}")

    # Calculate a simple feature-based risk score
    feature_score = (
        min(len(urls) * 1.5, 3.0) +
        min(len(set(urgent_words)) * 0.8, 2.5) +
        min(len(set(financial_words)) * 1.0, 2.0) +
        min(exclamations * 0.3, 1.0) +
        (1.0 if has_dear else 0.0) +
        (0.5 if dollar_signs > 0 else 0.0)
    )
    feature_score = round(min(feature_score, 10.0), 2)

    return {
        "word_count":       word_count,
        "url_count":        len(urls),
        "urls_found":       urls[:5],
        "urgent_words":     list(set(urgent_words)),
        "financial_words":  list(set(financial_words)),
        "exclamation_count": exclamations,
        "dollar_count":     dollar_signs,
        "has_generic_greeting": has_dear,
        "has_phone_number": has_phone,
        "caps_ratio":       round(caps_ratio, 3),
        "feature_risk_score": feature_score,
        "indicators":       indicators if indicators else ["No strong phishing indicators detected"],
        "summary": (
            f"Found {len(indicators)} phishing indicator(s). "
            f"Feature risk score: {feature_score}/10."
        )
    }


# ── Tool registry ─────────────────────────────────────────────────────────────

TOOL_SCHEMAS = [
    {"type": "function", "function": PREDICT_PHISHING_SCHEMA},
    {"type": "function", "function": RETRIEVE_GUIDELINES_SCHEMA},
    {"type": "function", "function": ANALYZE_EMAIL_SCHEMA},
]

TOOL_FUNCTIONS = {
    "predict_phishing":       lambda args: predict_phishing(args["email_text"]),
    "retrieve_guidelines":    lambda args: retrieve_guidelines(**args),
    "analyze_email_features": lambda args: analyze_email_features(args["email_text"]),
}


def dispatch_tool(tool_name: str, tool_args: dict) -> str:
    """Execute a tool call and return result as JSON string."""
    if tool_name not in TOOL_FUNCTIONS:
        return json.dumps({"error": f"Unknown tool: {tool_name}"})
    result = TOOL_FUNCTIONS[tool_name](tool_args)
    return json.dumps(result, indent=2)