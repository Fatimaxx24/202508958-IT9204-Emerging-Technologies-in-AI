"""
Part D - Decision & Reasoning Layer
Deterministic query routing that decides which tools to invoke.
"""

import re
from dataclasses import dataclass
from enum import Enum


class QueryPath(Enum):
    CLASSIFICATION = "A"  # email provided → ML + features + RAG
    GUIDANCE       = "B"  # policy/procedure question → RAG only
    EXPLANATION    = "C"  # explain indicators → features + RAG
    AMBIGUOUS      = "D"  # unclear → RAG fallback


@dataclass
class RoutingDecision:
    path:            QueryPath
    use_ml:          bool
    use_rag:         bool
    use_features:    bool
    reason:          str


# ── Keyword signals ───────────────────────────────────────────────────────────

_CLASSIFICATION_SIGNALS = [
    r"\b(is this|check this|analyze this|scan this)\b",
    r"\bphishing\b.*\b(email|message|mail)\b",
    r"http[s]?://",
    r"\burgent\b",
    r"\bsuspend(ed)?\b",
    r"\bverify\b.*\b(account|identity)\b",
    r"\bdear\s+(customer|user|winner|sir|madam)\b",
    r"\bclick\s+here\b",
    r"\$\d+",
]

_GUIDANCE_SIGNALS = [
    r"\bwhat should (i|we|you)\b",
    r"\bhow (do|should|can) (i|we)\b",
    r"\bwhat (is|are) the (steps|procedure|policy|guideline)\b",
    r"\bwhat to do\b",
    r"\bhow to (respond|report|handle|deal)\b",
    r"\bsteps\b",
    r"\bprocedure\b",
    r"\bpolicy\b",
    r"\brespond\b",
    r"\breport\b",
]

_EXPLANATION_SIGNALS = [
    r"\bwhy is\b",
    r"\bexplain\b",
    r"\bwhat makes\b",
    r"\bindicators?\b",
    r"\bsigns?\b",
    r"\bsuspicious\b",
    r"\bred flags?\b",
    r"\bfeatures?\b",
]


def _count_signals(text: str, patterns: list) -> int:
    text_lower = text.lower()
    return sum(1 for p in patterns if re.search(p, text_lower, re.IGNORECASE))


# ── Router ────────────────────────────────────────────────────────────────────

def classify_query(query: str) -> RoutingDecision:
    """
    Classify a user query into one of four routing paths.
    Returns a RoutingDecision describing which tools to invoke.
    """
    c = _count_signals(query, _CLASSIFICATION_SIGNALS)
    g = _count_signals(query, _GUIDANCE_SIGNALS)
    e = _count_signals(query, _EXPLANATION_SIGNALS)

    # Path A: email classification
    if c >= 2 or (c >= 1 and len(query) > 100) or (len(query) > 150 and g == 0 and e == 0):
        return RoutingDecision(
            path=QueryPath.CLASSIFICATION,
            use_ml=True,
            use_rag=True,
            use_features=True,
            reason=f"Classification signals ({c}) detected. "
                   "analyze_email_features → predict_phishing → retrieve_guidelines."
        )

    # Path C: explanation request
    if e >= 2 and e >= g:
        return RoutingDecision(
            path=QueryPath.EXPLANATION,
            use_ml=False,
            use_rag=True,
            use_features=True,
            reason=f"Explanation signals ({e}) detected. "
                   "analyze_email_features → retrieve_guidelines."
        )

    # Path B: guidance/policy question
    if g >= 1:
        return RoutingDecision(
            path=QueryPath.GUIDANCE,
            use_ml=False,
            use_rag=True,
            use_features=False,
            reason=f"Guidance signals ({g}) detected. retrieve_guidelines only."
        )

    # Path D: ambiguous
    return RoutingDecision(
        path=QueryPath.AMBIGUOUS,
        use_ml=False,
        use_rag=True,
        use_features=False,
        reason=f"No dominant signal (classification={c}, guidance={g}, explanation={e}). "
               "Defaulting to retrieve_guidelines."
    )


# ── Risk gating ───────────────────────────────────────────────────────────────

def should_retrieve_guidelines(ml_result: dict) -> bool:
    """Return True if ML score is high enough to warrant policy retrieval."""
    return ml_result.get("phishing_probability", 0.0) >= 0.70


# ── Decision flow diagram ─────────────────────────────────────────────────────

DECISION_DIAGRAM = """
╔══════════════════════════════════════════════════════════════════╗
║     PHISHING DETECTION ASSISTANT — DECISION FLOW                 ║
╚══════════════════════════════════════════════════════════════════╝

User Query
    │
    ▼
┌──────────────────────────┐
│   Query Classifier       │  (keyword analysis + LLM reasoning)
│   classify_query(q)      │
└──────────────────────────┘
    │
    ├──[Email content / classification signals ≥ 2]────────────────┐
    │                                                               ▼
    │                                          ┌─────────────────────────────┐
    │                                          │  analyze_email_features()   │
    │                                          │  (URLs, urgency, financial, │
    │                                          │   greeting, caps, etc.)     │
    │                                          └─────────────────────────────┘
    │                                                    │
    │                                                    ▼
    │                                          ┌─────────────────────────────┐
    │                                          │    predict_phishing()        │
    │                                          │    (Azure ML endpoint)       │
    │                                          └─────────────────────────────┘
    │                                                    │
    │                                       ┌──[prob ≥ 0.70]──────┐
    │                                       ▼                      ▼
    │                              retrieve_guidelines()     Low/Medium Risk
    │                              (escalation steps)        Log & Monitor
    │
    ├──[Explanation signals ≥ 2]───────────────────────────────────┐
    │                                                               ▼
    │                                          ┌─────────────────────────────┐
    │                                          │  analyze_email_features()   │
    │                                          │  + retrieve_guidelines()    │
    │                                          └─────────────────────────────┘
    │
    ├──[Guidance signals ≥ 1]──────────────────────────────────────┐
    │                                                               ▼
    │                                          ┌─────────────────────────────┐
    │                                          │     retrieve_guidelines()   │
    │                                          │  (RAG over knowledge base)  │
    │                                          └─────────────────────────────┘
    │
    └──[Ambiguous]──────────────────────────────────────────────────┐
                                                                    ▼
                                                   retrieve_guidelines() [safe default]

─────────────────────────────────────────────────────────────────────
Final step (all paths):
    LLM synthesizes tool outputs → grounded, explainable response
    Human analyst reviews → takes final action
─────────────────────────────────────────────────────────────────────
"""


if __name__ == "__main__":
    print(DECISION_DIAGRAM)

    test_queries = [
        "URGENT! Your PayPal account is suspended. Click: http://fake.com/verify",
        "What should I do if I clicked a phishing link?",
        "Why is this email suspicious? Explain the indicators.",
        "Tell me about email security",
    ]

    print("\n── Query Classification Tests ──\n")
    for q in test_queries:
        d = classify_query(q)
        print(f"Query: {q[:70]}")
        print(f"  Path: {d.path.name} ({d.path.value})")
        print(f"  ML={d.use_ml}  RAG={d.use_rag}  Features={d.use_features}")
        print(f"  Reason: {d.reason}\n")