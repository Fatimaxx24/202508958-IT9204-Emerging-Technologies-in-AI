"""
Part F - Evaluation and Analysis
Evaluates the full system: ML model performance, RAG retrieval quality,
agent response quality, error analysis, and Responsible AI considerations.
"""

import json
import sys
import time
from pathlib import Path
from datetime import datetime

BASE = Path(__file__).parent.parent
sys.path.insert(0, str(BASE / "C - Agent System"))
sys.path.insert(0, str(BASE / "D - Decision and Reasoning Layer"))
sys.path.insert(0, str(BASE / "A - Data and Knowledge Layer"))

from tools import predict_phishing, analyze_email_features, retrieve_guidelines
from decision_logic import classify_query

RESULTS_DIR = Path(__file__).parent
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

# ── Test cases ────────────────────────────────────────────────────────────────

TEST_CASES = [
    # Clear phishing emails
    {
        "id": "T01", "expected": "phishing", "category": "obvious_phishing",
        "query": "URGENT! Your bank account has been compromised. Verify immediately: http://secure-bank-verify.xyz/login. Dear Customer, act now or account will be closed!"
    },
    {
        "id": "T02", "expected": "phishing", "category": "prize_scam",
        "query": "Congratulations! You have won $1,000,000 prize! Click here to claim: http://prize-claim-now.net. Send your bank details immediately to receive funds!"
    },
    {
        "id": "T03", "expected": "phishing", "category": "credential_harvest",
        "query": "Dear User, your Microsoft account password expires today. Update your password now: http://microsoft-password-update.xyz otherwise you will lose access!"
    },
    # Safe emails
    {
        "id": "T04", "expected": "safe", "category": "business_email",
        "query": "Hi Sarah, please find the meeting agenda for tomorrow attached. The quarterly review starts at 10am in conference room B. Let me know if you have questions."
    },
    {
        "id": "T05", "expected": "safe", "category": "colleague_email",
        "query": "Hello team, just a reminder that the project deadline is next Friday. Please submit your reports to the shared drive by Thursday end of day. Thanks, Ahmed."
    },
    {
        "id": "T06", "expected": "safe", "category": "newsletter",
        "query": "Welcome to our monthly newsletter. This month we cover the latest updates in cloud computing, AI trends, and our upcoming webinar series. Unsubscribe anytime."
    },
    # Guidance questions
    {
        "id": "T07", "expected": "guidance", "category": "incident_response",
        "query": "What should I do if I receive a suspicious email asking for my password?"
    },
    {
        "id": "T08", "expected": "guidance", "category": "policy_question",
        "query": "What are the steps to report a phishing email in my organization?"
    },
    # Borderline cases
    {
        "id": "T09", "expected": "review", "category": "borderline",
        "query": "Dear Customer, your order has been shipped. Track your package here: http://tracking.dhl.com/123456. Expected delivery Friday."
    },
    {
        "id": "T10", "expected": "review", "category": "borderline",
        "query": "Your subscription is expiring soon. Please renew your account to continue enjoying our services. Visit our website to update your payment details."
    },
]


def evaluate_system():
    """Run full system evaluation."""
    print("=" * 65)
    print("  SYSTEM EVALUATION — Phishing Detection Assistant")
    print("  IT9204 | Fatema Hasan (202508958)")
    print("=" * 65)

    results = []
    correct = 0
    total_phishing = 0
    correct_phishing = 0
    total_safe = 0
    correct_safe = 0
    total_guidance = 0
    correct_guidance = 0

    for tc in TEST_CASES:
        print(f"\n[{tc['id']}] Category: {tc['category']}")
        print(f"Query: {tc['query'][:80]}...")

        start = time.time()
        routing = classify_query(tc["query"])
        tools_called = []
        ml_result = None

        if tc["expected"] in ("phishing", "safe", "review"):
            # Directly call tools for email classification
            features = analyze_email_features(tc["query"])
            tools_called.append("analyze_email_features")

            ml_result = predict_phishing(tc["query"])
            tools_called.append("predict_phishing")

            if ml_result.get("phishing_probability", 0) >= 0.70:
                guidelines = retrieve_guidelines(
                    "phishing response procedures", top_k=3
                )
                tools_called.append("retrieve_guidelines")
        else:
            # Guidance — use RAG only
            guidelines = retrieve_guidelines(tc["query"], top_k=3)
            tools_called.append("retrieve_guidelines")

        elapsed = round(time.time() - start, 2)

        if ml_result:
            prob   = ml_result.get("phishing_probability", 0)
            actual = "phishing" if prob >= 0.5 else "safe"
        else:
            actual = "guidance"
            prob   = None

        is_correct = (
            (tc["expected"] == "phishing" and actual == "phishing") or
            (tc["expected"] == "safe"     and actual == "safe")     or
            (tc["expected"] == "guidance" and actual == "guidance") or
            (tc["expected"] == "review")
        )

        if is_correct and tc["expected"] != "review":
            correct += 1
        if tc["expected"] == "phishing":
            total_phishing += 1
            if actual == "phishing":
                correct_phishing += 1
        elif tc["expected"] == "safe":
            total_safe += 1
            if actual == "safe":
                correct_safe += 1
        elif tc["expected"] == "guidance":
            total_guidance += 1
            if actual == "guidance":
                correct_guidance += 1

        print(f"  Expected: {tc['expected']} | Actual: {actual} | "
              f"{'✅' if is_correct else '❌'} | Time: {elapsed}s")
        if prob is not None:
            print(f"  ML Score: {prob:.4f} | Risk: {ml_result.get('risk_level','N/A')}")
        print(f"  Tools: {tools_called}")
        print(f"  Routing: Path {routing.path.value} — {routing.reason[:60]}...")

        results.append({
            "id":             tc["id"],
            "category":       tc["category"],
            "expected":       tc["expected"],
            "actual":         actual,
            "correct":        is_correct,
            "routing_path":   routing.path.name,
            "tools_called":   tools_called,
            "ml_probability": prob,
            "response_time_s": elapsed,
        })

    # ── Summary ───────────────────────────────────────────────────────────────
    judged   = [r for r in results if r["expected"] != "review"]
    accuracy = correct / len(judged) if judged else 0

    print(f"\n{'='*65}")
    print("  EVALUATION SUMMARY")
    print(f"{'='*65}")
    print(f"Overall accuracy:      {accuracy:.1%} ({correct}/{len(judged)} judged cases)")
    print(f"Phishing detection:    {correct_phishing}/{total_phishing} correct")
    print(f"Safe classification:   {correct_safe}/{total_safe} correct")
    print(f"Guidance routing:      {correct_guidance}/{total_guidance} correct")
    print(f"Borderline cases:      {len([r for r in results if r['expected']=='review'])} (flagged for review)")
    avg_time = sum(r["response_time_s"] for r in results) / len(results)
    print(f"Average response time: {avg_time:.2f}s")

    # ── RAG evaluation ────────────────────────────────────────────────────────
    print(f"\n── RAG Retrieval Quality ──────────────────────────────")
    rag_queries = [
        "what are signs of phishing",
        "how to respond to phishing incident",
        "email authentication SPF DKIM",
    ]
    for q in rag_queries:
        from rag_pipeline import retrieve_documents
        docs    = retrieve_documents(q, top_k=3)
        sources = [d["source"] for d in docs]
        scores  = [round(d["score"], 4) for d in docs]
        print(f"Query: '{q}'")
        print(f"  Sources: {sources}")
        print(f"  Scores:  {scores}")

    # ── Save results ──────────────────────────────────────────────────────────
    eval_output = {
        "timestamp":         timestamp,
        "overall_accuracy":  accuracy,
        "phishing_recall":   correct_phishing / total_phishing if total_phishing else 0,
        "safe_precision":    correct_safe / total_safe if total_safe else 0,
        "guidance_accuracy": correct_guidance / total_guidance if total_guidance else 0,
        "avg_response_time": avg_time,
        "test_results":      results,
        "responsible_ai": {
            "bias_consideration":
                "Model trained on English emails only — may have lower accuracy on non-English phishing attempts",
            "false_negative_risk":
                "Missing phishing emails (false negatives) poses higher risk than false positives",
            "human_oversight":
                "System is designed as decision support — all verdicts require human review",
            "data_privacy":
                "Email content processed for classification — organizations must ensure GDPR/PDPL compliance",
            "transparency":
                "All predictions include probability scores and indicator explanations for auditability",
            "limitations": [
                "Text-based only — cannot analyze images or QR codes in emails",
                "May miss sophisticated spear phishing with no obvious indicators",
                "Model performance may degrade on new phishing techniques not in training data",
                "Azure ML endpoint availability depends on cloud connectivity",
                "Content filter may block analysis of some highly explicit phishing samples"
            ]
        }
    }

    out_path = RESULTS_DIR / f"evaluation_results_{timestamp}.json"
    with open(out_path, "w") as f:
        json.dump(eval_output, f, indent=2)
    print(f"\n[Evaluation results saved to: {out_path}]")
    return eval_output


if __name__ == "__main__":
    evaluate_system()