"""
Part A - Data & Knowledge Layer
RAG Pipeline: document ingestion, chunking, embedding, and retrieval
using Azure AI Search (vector search) + BM25 hybrid search (Part I - Extra).
"""

import os
import re
import json
import glob
from pathlib import Path
from dotenv import load_dotenv

from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex, SearchField, SearchFieldDataType,
    SimpleField, SearchableField, VectorSearch,
    HnswAlgorithmConfiguration, VectorSearchProfile,
)
from azure.search.documents.models import VectorizedQuery
from azure.core.credentials import AzureKeyCredential
from openai import AzureOpenAI

# Load environment variables
load_dotenv(dotenv_path=Path(__file__).parent.parent / "E - System Integration" / ".env")

# Config
SEARCH_ENDPOINT   = os.getenv("AZURE_SEARCH_ENDPOINT")
SEARCH_KEY        = os.getenv("AZURE_SEARCH_KEY")
SEARCH_INDEX      = os.getenv("AZURE_SEARCH_INDEX", "phishing-knowledge-base")
OPENAI_ENDPOINT   = os.getenv("AZURE_OPENAI_ENDPOINT")
OPENAI_KEY        = os.getenv("AZURE_OPENAI_API_KEY")
OPENAI_VERSION    = os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview")
EMBED_DEPLOYMENT  = os.getenv("AZURE_EMBED_DEPLOYMENT", "text-embedding-3-small")
EMBED_DIMENSIONS  = 1536
CHUNK_SIZE        = 300
CHUNK_OVERLAP     = 50
TOP_K             = 3

# Clients
credential    = AzureKeyCredential(SEARCH_KEY)
index_client  = SearchIndexClient(endpoint=SEARCH_ENDPOINT, credential=credential)
search_client = SearchClient(endpoint=SEARCH_ENDPOINT, index_name=SEARCH_INDEX, credential=credential)
openai_client = AzureOpenAI(azure_endpoint=OPENAI_ENDPOINT, api_key=OPENAI_KEY, api_version=OPENAI_VERSION)


# ── Index creation ────────────────────────────────────────────────────────────

def create_search_index():
    """Create Azure AI Search index with vector search support."""
    fields = [
        SimpleField(name="id",          type=SearchFieldDataType.String, key=True),
        SearchableField(name="content", type=SearchFieldDataType.String),
        SimpleField(name="source",      type=SearchFieldDataType.String, filterable=True),
        SimpleField(name="chunk_index", type=SearchFieldDataType.Int32),
        SearchField(
            name="embedding",
            type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
            searchable=True,
            vector_search_dimensions=EMBED_DIMENSIONS,
            vector_search_profile_name="hnsw-profile",
        ),
    ]
    vector_search = VectorSearch(
        algorithms=[HnswAlgorithmConfiguration(name="hnsw-algo")],
        profiles=[VectorSearchProfile(name="hnsw-profile", algorithm_configuration_name="hnsw-algo")],
    )
    index = SearchIndex(name=SEARCH_INDEX, fields=fields, vector_search=vector_search)
    index_client.create_or_update_index(index)
    print(f"Index '{SEARCH_INDEX}' created/updated.")


# ── Chunking ──────────────────────────────────────────────────────────────────

def chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """Split text into overlapping word-based chunks."""
    words  = text.split()
    chunks = []
    start  = 0
    while start < len(words):
        end = start + chunk_size
        chunks.append(" ".join(words[start:end]))
        start += chunk_size - overlap
    return chunks


# ── Embedding ─────────────────────────────────────────────────────────────────

def embed(texts: list[str]) -> list[list[float]]:
    """Embed a list of texts using Azure OpenAI text-embedding-3-small."""
    response = openai_client.embeddings.create(
        input=texts,
        model=EMBED_DEPLOYMENT,
    )
    return [item.embedding for item in response.data]


# ── Ingestion ─────────────────────────────────────────────────────────────────

def ingest_documents(docs_folder: str):
    """
    Read all .md files from docs_folder, chunk, embed, and upload to Azure AI Search.
    """
    create_search_index()

    doc_paths = glob.glob(os.path.join(docs_folder, "*.md"))
    if not doc_paths:
        print("No .md documents found in", docs_folder)
        return

    all_documents = []
    for path in doc_paths:
        source_name = Path(path).stem
        print(f"Processing: {source_name}")

        with open(path, "r", encoding="utf-8") as f:
            text = f.read()

        # Clean markdown symbols
        text_clean = re.sub(r"[#*`|_\-]+", " ", text)
        text_clean = re.sub(r"\s+", " ", text_clean).strip()

        chunks     = chunk_text(text_clean)
        embeddings = embed(chunks)

        for i, (chunk, vector) in enumerate(zip(chunks, embeddings)):
            all_documents.append({
                "id":          f"{source_name}-{i}",
                "content":     chunk,
                "source":      source_name,
                "chunk_index": i,
                "embedding":   vector,
            })

        print(f"  → {len(chunks)} chunks created")

    # Upload in batches of 100
    batch_size = 100
    for i in range(0, len(all_documents), batch_size):
        batch = all_documents[i: i + batch_size]
        search_client.upload_documents(documents=batch)
        print(f"  Uploaded chunks {i} – {i + len(batch) - 1}")

    print(f"\nIngestion complete. Total chunks: {len(all_documents)}")


# ── Retrieval ─────────────────────────────────────────────────────────────────

def retrieve_documents(query: str, top_k: int = TOP_K) -> list[dict]:
    """
    Retrieve relevant chunks using vector search.
    Returns list of dicts with source, content, score.
    """
    query_vector = embed([query])[0]
    vector_query = VectorizedQuery(
        vector=query_vector,
        k_nearest_neighbors=top_k,
        fields="embedding",
    )
    results = search_client.search(
        search_text=None,
        vector_queries=[vector_query],
        select=["source", "content"],
        top=top_k,
    )
    retrieved = []
    for r in results:
        retrieved.append({
            "source":  r["source"],
            "content": r["content"],
            "score":   r["@search.score"],
        })
    return retrieved


def format_context(results: list[dict]) -> str:
    """Format retrieved chunks into a context string for the LLM."""
    if not results:
        return "No relevant documents found."
    parts = []
    for i, r in enumerate(results, 1):
        parts.append(f"[Source {i}: {r['source']}]\n{r['content']}")
    return "\n\n---\n\n".join(parts)


# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--ingest", action="store_true", help="Ingest RAG documents")
    parser.add_argument("--query",  type=str, help="Test retrieval with a query")
    parser.add_argument("--docs",   type=str,
                        default=str(Path(__file__).parent / "RAG Documents"),
                        help="Path to RAG documents folder")
    args = parser.parse_args()

    if args.ingest:
        print(f"Ingesting documents from: {args.docs}")
        ingest_documents(args.docs)

    if args.query:
        print(f"\nQuery: {args.query}")
        results = retrieve_documents(args.query)
        print(f"Retrieved {len(results)} chunks:")
        for r in results:
            print(f"\n[{r['source']}] (score={r['score']:.4f})")
            print(r["content"][:300], "...")