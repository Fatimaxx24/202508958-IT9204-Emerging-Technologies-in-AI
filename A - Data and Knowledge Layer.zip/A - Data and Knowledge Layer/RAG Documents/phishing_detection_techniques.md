# Phishing Detection Techniques and Technical Indicators

## Overview

This document provides technical guidance on detecting phishing emails using both automated and manual analysis techniques. It covers linguistic indicators, structural email analysis, URL analysis, and machine learning approaches to phishing detection.

## Linguistic and Content-Based Indicators

### Urgency and Emotional Manipulation
Phishing emails frequently use urgency, fear, and emotional pressure to override the recipient's critical thinking. Common urgency phrases include:
- "Your account has been suspended"
- "Immediate action required"
- "Verify your account within 24 hours to avoid suspension"
- "You have won a prize — claim now"
- "Unauthorized access detected on your account"
- "Final notice: payment overdue"

Research shows that urgency language is present in over 70% of confirmed phishing emails. An AI system analyzing email content should assign higher phishing probability to emails containing multiple urgency indicators.

### Financial and Credential Request Language
Legitimate organizations rarely request sensitive information via email. The presence of requests for the following information is a strong phishing indicator:
- Passwords or PINs
- Credit card numbers or CVV codes
- Bank account or routing numbers
- Social security numbers or national ID numbers
- One-time passwords or authentication codes
- PayPal, cryptocurrency, or wire transfer instructions

### Greeting Patterns
Phishing emails often use generic greetings because they are sent in bulk to many recipients:
- "Dear Customer"
- "Dear User"
- "Dear Account Holder"
- "Dear [email address]"

The use of "Dear" followed by a generic term rather than the recipient's actual name is a reliable phishing indicator, particularly when combined with other signals.

### Excessive Punctuation and Capitalization
Phishing emails often use excessive exclamation marks, ALL CAPS text, and dollar signs to convey urgency or excitement. High counts of these characters relative to the total email length are associated with higher phishing probability.

## Structural Email Analysis

### Email Header Analysis
A thorough analysis of email headers reveals important information about the true origin and routing of an email:

**From vs. Reply-To mismatch**: When the Reply-To address differs from the From address, replies will be directed to the attacker rather than the apparent sender. This is a common technique in business email compromise attacks.

**Return-Path analysis**: The Return-Path header indicates where bounce messages are sent. A mismatch between the Return-Path domain and the From domain suggests spoofing.

**Received headers**: The chain of Received headers traces the path of the email through mail servers. Unexpected routing through servers in unusual geographic locations or through known malicious IP ranges is suspicious.

**Authentication results**: The Authentication-Results header shows the outcome of SPF, DKIM, and DMARC checks. Failed or missing authentication is a significant phishing indicator.

### Sender Domain Analysis
- **Typosquatting**: Domains that closely resemble legitimate domains (paypa1.com, amazon-security.com, microsoft-support.net)
- **New domain registration**: Phishing domains are often registered shortly before use. Domains less than 30 days old sending email claiming to be from established organizations are suspicious.
- **Free email providers**: Emails claiming to be from banks, government agencies, or major corporations sent from Gmail, Yahoo, Hotmail, or similar free email services are suspicious.
- **Subdomain abuse**: Legitimate-sounding subdomains on suspicious root domains (e.g., paypal.login.malicious-domain.com)

## URL and Link Analysis

### Indicators of Malicious URLs
- **URL shorteners**: Services such as bit.ly, tinyurl, or ow.ly are used to obscure the true destination of links.
- **IP address links**: Legitimate organizations use domain names, not raw IP addresses, in their communications.
- **Excessive URL parameters**: Long, complex URLs with many parameters may be used to redirect through legitimate websites to malicious destinations.
- **Homograph attacks**: URLs using Unicode characters that visually resemble standard Latin characters (e.g., using Cyrillic "а" instead of Latin "a").
- **HTTPS on phishing sites**: The presence of HTTPS and a valid SSL certificate does not indicate a legitimate website. Attackers routinely obtain free SSL certificates for phishing sites.

### Redirect Chains
Phishing emails often use multiple redirects to evade detection. The email contains a link to a legitimate or benign-appearing website, which then redirects to the actual phishing page. Security systems that only analyze the first URL in a link will miss this technique.

## Machine Learning Approaches to Phishing Detection

### Feature Engineering for Email Classification
Effective machine learning models for phishing detection typically use a combination of:

**Text-based features:**
- TF-IDF (Term Frequency-Inverse Document Frequency) representations of email body text
- N-gram features capturing common phishing phrases
- Character-level features detecting unusual character patterns

**Structural features:**
- Presence and count of URLs
- Presence of HTML content vs. plain text
- Ratio of image content to text content
- Email length and formatting characteristics

**Engineered phishing signal features:**
- Binary indicators for urgency vocabulary
- Binary indicators for financial vocabulary
- Count of exclamation marks and dollar signs
- Presence of generic greeting patterns
- URL count and pattern analysis
- Capitalization ratio

### Model Selection Considerations
- **Logistic Regression with TF-IDF**: Fast, interpretable, and effective for text classification. Provides probability scores that can be used for risk thresholding.
- **Random Forest**: Handles mixed feature types well and provides feature importance scores for explainability.
- **Gradient Boosting (XGBoost, LightGBM)**: Often achieves highest accuracy on structured feature sets.
- **Deep Learning (BERT, RoBERTa)**: State-of-the-art performance but requires more computational resources and training data.

### Performance Metrics
For phishing detection, recall (sensitivity) for the phishing class is typically prioritized over precision, as the cost of missing a phishing email (false negative) is higher than the cost of incorrectly flagging a legitimate email (false positive). Typical performance targets:
- Phishing recall: > 95%
- False positive rate: < 2%
- AUC-ROC: > 0.95

## Risk Thresholds and Classification

A phishing probability score from a machine learning model can be converted to a risk level using the following thresholds:

| Probability | Risk Level | Recommended Action |
|-------------|------------|-------------------|
| 0.00 - 0.30 | Low | Deliver normally, log for monitoring |
| 0.30 - 0.60 | Medium | Flag for user awareness, add warning banner |
| 0.60 - 0.80 | High | Quarantine for review, notify user |
| 0.80 - 1.00 | Critical | Block delivery, alert security team |

These thresholds should be calibrated based on the organization's risk tolerance and the observed false positive rate in production.
