# CISA Phishing Guidance: Stopping the Attack Cycle at Phase One

## Source: Cybersecurity and Infrastructure Security Agency (CISA)

## What is Phishing?

Phishing is a form of social engineering attack in which a threat actor attempts to deceive a user into revealing sensitive information or performing an action that benefits the attacker. Phishing emails typically impersonate trusted entities such as banks, government agencies, technology companies, or colleagues. The goal is to trick the recipient into clicking a malicious link, downloading a malware-laden attachment, or providing credentials and personal information.

Phishing represents one of the most prevalent and effective initial access techniques used by cyber threat actors. It is consistently ranked as the top initial attack vector in major cybersecurity incidents and data breaches worldwide.

## Types of Phishing Attacks

### Spear Phishing
Spear phishing is a targeted form of phishing directed at specific individuals or organizations. Unlike generic phishing campaigns, spear phishing emails are personalized using information gathered about the target. Threat actors may reference the target's name, job title, employer, colleagues, or recent activities to make the email appear legitimate.

### Whaling
Whaling is a type of spear phishing that specifically targets high-profile individuals such as senior executives, board members, or government officials. These attacks often impersonate legal authorities, regulatory bodies, or business partners and may involve large financial transactions or sensitive corporate data.

### Smishing and Vishing
Smishing uses SMS text messages to deliver phishing content, while vishing uses voice calls. These variants are increasingly common and may be used in combination with email-based phishing as part of multi-channel attack campaigns.

### Clone Phishing
Clone phishing involves duplicating a legitimate email that the target has previously received, replacing links or attachments with malicious versions, and resending the email from a spoofed address. Because the email appears familiar to the recipient, it is more likely to succeed.

## Common Phishing Indicators

Organizations and users should be alert to the following indicators of phishing emails:

- **Urgency and pressure**: Emails that demand immediate action, threaten account suspension, or warn of negative consequences if the recipient does not respond immediately.
- **Suspicious sender addresses**: Email addresses that closely resemble legitimate domains but contain subtle misspellings, extra characters, or different top-level domains (e.g., support@paypa1.com instead of support@paypal.com).
- **Unexpected attachments**: Unsolicited attachments, particularly executable files (.exe), compressed archives (.zip, .rar), or Office documents with macros enabled.
- **Unusual or mismatched links**: Hyperlinks where the displayed text does not match the actual URL destination. Users should hover over links before clicking to verify the true destination.
- **Requests for credentials or personal information**: Legitimate organizations rarely request passwords, social security numbers, credit card numbers, or other sensitive information via email.
- **Poor grammar and spelling**: While sophisticated attacks may be grammatically correct, many phishing emails contain spelling errors, awkward phrasing, or unusual formatting.
- **Generic greetings**: Phishing emails often use generic salutations such as "Dear Customer" or "Dear User" rather than the recipient's actual name.
- **Mismatched branding**: Logos, colors, or formatting that do not match the legitimate organization's standard communications.

## CISA Recommended Actions for Organizations

### Implement Email Security Controls
- Deploy email authentication protocols including SPF (Sender Policy Framework), DKIM (DomainKeys Identified Mail), and DMARC (Domain-based Message Authentication, Reporting, and Conformance) to prevent email spoofing.
- Enable anti-phishing and anti-malware filters on all organizational email systems.
- Configure email gateways to quarantine or reject emails that fail authentication checks.
- Implement URL rewriting and time-of-click analysis to detect malicious links even after email delivery.

### Conduct Regular User Awareness Training
- Provide mandatory phishing awareness training to all employees at least annually, with targeted training for high-risk roles such as finance and executive staff.
- Conduct simulated phishing exercises to measure employee susceptibility and reinforce training effectiveness.
- Train users to report suspicious emails to the IT security team immediately without clicking any links or opening attachments.

### Establish Incident Response Procedures
- Define clear procedures for reporting, investigating, and responding to phishing incidents.
- Establish a dedicated email address or reporting button for employees to report suspicious emails.
- Ensure that all reported phishing emails are reviewed by security personnel within a defined timeframe.

### Apply the Principle of Least Privilege
- Limit user access rights to the minimum necessary for their job function.
- Restrict administrative privileges to reduce the impact of a successful phishing attack that captures credentials.
- Implement multi-factor authentication (MFA) on all accounts, particularly those with access to sensitive systems or data.

## Recommended User Actions When a Phishing Email is Suspected

1. Do not click any links or open any attachments in the email.
2. Do not reply to the email or contact the sender through any contact information provided in the email.
3. Report the email to your organization's IT security team or helpdesk using the designated reporting channel.
4. If you have already clicked a link or opened an attachment, immediately disconnect from the network and contact IT security.
5. Change passwords immediately if credentials may have been compromised, starting with email and financial accounts.
6. Monitor financial accounts and credit reports for unauthorized activity.

## Phishing in the Context of Broader Attack Campaigns

Phishing is frequently used as the first stage of a multi-phase attack. After obtaining credentials or installing malware via phishing, threat actors may:

- Move laterally within the organization's network to access additional systems.
- Escalate privileges to gain administrative access.
- Exfiltrate sensitive data including intellectual property, customer records, or financial information.
- Deploy ransomware to encrypt organizational data and demand payment.
- Establish persistent access for long-term espionage or repeated attacks.

Stopping phishing at the initial phase is therefore critical to preventing significant downstream harm to the organization.

## Legal and Regulatory Implications

Organizations that experience data breaches resulting from phishing attacks may face regulatory penalties under applicable data protection laws including GDPR, HIPAA, PCI DSS, and various national cybersecurity regulations. Organizations are expected to demonstrate that they have implemented reasonable security measures, including email security controls and user awareness training, to reduce phishing risk.
