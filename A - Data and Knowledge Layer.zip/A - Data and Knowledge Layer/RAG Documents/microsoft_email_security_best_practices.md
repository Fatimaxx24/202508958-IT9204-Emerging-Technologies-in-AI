# Microsoft Email Security Best Practices and Anti-Phishing Guidance

## Source: Microsoft Security Documentation

## Overview

Email remains the primary attack vector for cybercriminals seeking to compromise individuals and organizations. Microsoft processes billions of emails daily across its platforms and has identified consistent patterns in phishing and malicious email campaigns. This document outlines best practices for identifying, preventing, and responding to email-based threats based on Microsoft's security research and recommendations.

## How Microsoft Identifies Phishing Emails

Microsoft Defender for Office 365 and Exchange Online Protection use multiple layers of analysis to detect phishing emails:

### Sender Authentication Analysis
- **SPF verification**: Checks whether the sending server is authorized to send email on behalf of the claimed domain.
- **DKIM verification**: Validates the cryptographic signature attached to the email to confirm it has not been tampered with.
- **DMARC policy enforcement**: Applies the domain owner's policy for handling emails that fail SPF or DKIM checks.
- **Composite authentication (compauth)**: A Microsoft-proprietary score that combines multiple authentication signals to assess the legitimacy of the sender.

### Content Analysis
- Machine learning models trained on billions of signals analyze email content, headers, and metadata for phishing indicators.
- URL detonation: Suspicious links are opened in a sandboxed environment to detect malicious behavior before delivery.
- Attachment detonation: Suspicious attachments are executed in a controlled environment to identify malware.
- Impersonation detection: The system identifies emails that impersonate known contacts, domains, or brands.

## Common Phishing Techniques Observed by Microsoft

### Brand Impersonation
Attackers impersonate well-known brands including Microsoft, PayPal, Amazon, banking institutions, and government agencies. These emails typically direct recipients to convincing replica websites designed to capture credentials.

### Business Email Compromise (BEC)
BEC attacks involve impersonating executives, vendors, or partners to trick employees into transferring funds, changing payment details, or disclosing sensitive information. These attacks often do not contain malicious links or attachments and therefore bypass traditional email security filters.

### Credential Harvesting
Phishing emails direct users to fake login pages that capture usernames and passwords. These pages often use HTTPS and may display valid SSL certificates to appear legitimate. The presence of HTTPS alone does not guarantee a website is safe.

### Malware Delivery
Phishing emails deliver malware through:
- Malicious attachments (Office documents with macros, PDF files with embedded scripts, compressed archives containing executables)
- Links to malware download sites
- Links to compromised legitimate websites hosting malware

### Multi-Stage Attacks
Modern phishing campaigns often involve multiple stages. An initial phishing email may deliver a dropper that downloads additional malware components, or may capture credentials that are later used to access corporate systems for lateral movement and data exfiltration.

## Key Phishing Email Indicators

### Header Indicators
- Reply-To address differs from the From address
- Received headers show routing through unexpected geographic regions or suspicious mail servers
- X-Mailer headers indicating bulk email sending tools
- Missing or failed authentication headers (SPF fail, DKIM none, DMARC fail)

### Content Indicators
- Urgent calls to action: "Your account will be suspended in 24 hours"
- Requests for sensitive information: passwords, credit card numbers, social security numbers
- Links where the displayed URL does not match the actual destination URL
- Links using URL shorteners to obscure the true destination
- Domain names that closely resemble legitimate domains (typosquatting)
- Excessive use of images with minimal text (to evade text-based filters)
- Requests to enable macros in Office documents

### Behavioral Indicators
- Email received outside normal business hours from internal-seeming senders
- Unusual requests that deviate from established business processes
- Pressure to bypass normal verification or approval procedures
- Requests to communicate outside normal channels

## Microsoft Recommended Security Controls

### For Organizations
1. **Enable multi-factor authentication (MFA)** on all user accounts, particularly Microsoft 365 accounts. MFA prevents credential theft from being sufficient for account compromise.
2. **Deploy Microsoft Defender for Office 365** with Safe Links and Safe Attachments policies enabled.
3. **Configure anti-phishing policies** including impersonation protection for key personnel and domains.
4. **Enable attack simulation training** to run simulated phishing campaigns and provide targeted training to vulnerable users.
5. **Implement Conditional Access policies** to require compliant devices and block access from risky sign-in locations.
6. **Enable unified audit logging** to maintain records of user and administrator activity for incident investigation.
7. **Configure email quarantine policies** to hold suspicious emails for review rather than delivering them to user inboxes.

### For Individual Users
1. Verify the sender's email address carefully before responding or clicking links, paying attention to subtle misspellings.
2. Hover over links before clicking to verify the true destination URL.
3. Never enter credentials on a website reached through an email link — navigate directly to the website instead.
4. Be suspicious of any email that creates urgency or requests sensitive information.
5. Use the Report Message or Report Phishing button in Outlook to report suspicious emails to Microsoft and your IT team.
6. Keep software and operating systems updated to protect against malware delivered through phishing.

## Responding to a Phishing Incident

### Immediate Actions
1. Isolate affected systems from the network if malware may have been installed.
2. Reset passwords for compromised accounts and any accounts using the same password.
3. Revoke active sessions and tokens for compromised accounts.
4. Review sign-in logs and audit logs for unauthorized access.
5. Block the malicious sender domain and URLs at the email gateway.

### Investigation Steps
1. Identify all recipients of the phishing email within the organization.
2. Determine whether any recipients clicked links or opened attachments.
3. Analyze email headers to identify the true origin of the phishing campaign.
4. Check for indicators of compromise on systems accessed by affected users.
5. Preserve evidence for forensic analysis and regulatory reporting.

### Notification Requirements
Depending on the nature of data exposed, organizations may be required to notify affected individuals, regulatory bodies, or law enforcement. Consult legal counsel to determine applicable notification obligations under GDPR, HIPAA, or other relevant regulations.

## Microsoft Security Score and Phishing Protection

Microsoft Secure Score provides organizations with a measurable score reflecting their security posture. Actions that improve phishing protection and contribute to Secure Score include:
- Enabling MFA for all users
- Enabling Safe Links and Safe Attachments
- Configuring DMARC, DKIM, and SPF
- Completing attack simulation training
- Enabling sign-in risk policies
