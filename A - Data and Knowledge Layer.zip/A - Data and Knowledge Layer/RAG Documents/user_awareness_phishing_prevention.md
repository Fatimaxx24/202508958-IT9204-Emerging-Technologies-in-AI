# User Awareness Guide: Recognizing and Avoiding Phishing Attacks

## Introduction

Phishing attacks succeed because they exploit human psychology rather than technical vulnerabilities. Even organizations with the most sophisticated technical security controls can be compromised if employees are not trained to recognize and report phishing attempts. This guide provides practical guidance for all users on how to identify phishing emails and what to do when they receive one.

## The Psychology of Phishing

Understanding why phishing works helps users recognize when they are being manipulated. Phishing emails exploit several psychological principles:

### Authority
Phishing emails often impersonate authority figures or trusted organizations such as banks, government agencies, technology companies, or senior management. People are conditioned to comply with requests from authority figures, making them more likely to follow instructions in these emails without questioning their legitimacy.

### Urgency and Scarcity
Creating a sense of urgency compels people to act quickly without thinking carefully. Phrases like "Your account will be closed in 24 hours" or "Limited time offer — act now" pressure recipients into making hasty decisions that they would not make with more time to reflect.

### Fear
Threatening negative consequences such as account suspension, legal action, or financial loss triggers an emotional response that overrides rational thinking. When people are afraid, they are more likely to comply with demands without verifying their legitimacy.

### Social Proof and Trust
Impersonating known contacts, colleagues, or trusted brands creates a false sense of legitimacy. People are more likely to trust and act on communications that appear to come from someone or something they already trust.

### Reciprocity
Some phishing attacks offer something valuable — a prize, a refund, or a gift — to encourage the recipient to take action. The sense of obligation to reciprocate a gift or benefit can override skepticism.

## Practical Guide to Identifying Phishing Emails

### Step 1: Check the Sender's Email Address
Do not rely on the display name — look at the actual email address. Click on the sender's name to reveal the full email address. Check for:
- Misspellings in the domain name (e.g., microsofft.com, amazon-security.net)
- Free email providers (gmail.com, yahoo.com) claiming to be from official organizations
- Domains that look similar but are slightly different from the legitimate organization's domain

### Step 2: Look for Urgency and Pressure
Be suspicious of any email that:
- Demands immediate action within a short timeframe
- Threatens negative consequences for inaction
- Claims that your account has been compromised and requires immediate verification
- Offers prizes or rewards that require immediate action to claim

Legitimate organizations give you time to verify requests and do not threaten immediate negative consequences for taking a moment to think.

### Step 3: Verify Links Before Clicking
Before clicking any link in an email:
- Hover your mouse over the link (without clicking) to see the actual URL destination in your browser's status bar or a tooltip.
- Check that the domain in the URL matches the legitimate organization's website.
- Be especially wary of URL shorteners (bit.ly, tinyurl.com) that hide the true destination.
- Look for HTTPS in the URL but remember that HTTPS alone does not guarantee a site is legitimate.

If you are unsure whether a link is safe:
- Do not click the link.
- Navigate directly to the organization's website by typing the address into your browser.
- Call the organization using a phone number from their official website — not from the email.

### Step 4: Be Cautious with Attachments
Do not open attachments from unexpected emails, even if they appear to come from known contacts. Be especially cautious with:
- Office documents (.doc, .xls, .ppt) that prompt you to enable macros or editing
- Compressed archive files (.zip, .rar) containing executable files
- PDF files from unknown senders
- Executable files (.exe, .bat, .cmd) — these should never be sent via email

If you receive an unexpected attachment from a known contact, verify with them through a separate channel (phone or in-person) that they intentionally sent it before opening.

### Step 5: Check the Content for Quality and Relevance
- Does the email address you by your actual name, or does it use a generic greeting?
- Is the content relevant to something you actually have an account with or have recently done?
- Are there spelling errors, awkward grammar, or unusual formatting?
- Does the request make sense in the context of your relationship with the sender?

### Step 6: Trust Your Instincts
If something feels wrong about an email, trust that feeling. It is always better to spend a few minutes verifying a suspicious email than to fall victim to a phishing attack. The inconvenience of verifying a legitimate email is far less than the damage caused by a successful phishing attack.

## What to Do When You Receive a Suspicious Email

### If you have NOT clicked any links or opened attachments:
1. Do not click any links or open any attachments.
2. Report the email to your IT security team using the designated reporting method.
3. Delete the email from your inbox after reporting it.
4. Warn colleagues if you believe they may have received the same email.

### If you HAVE clicked a link but did not enter any information:
1. Close the browser tab or window immediately.
2. Report the incident to your IT security team right away, explaining that you clicked a link.
3. Run a malware scan on your device if possible.
4. Change your passwords as a precaution, starting with your email account.
5. Monitor your accounts for unusual activity.

### If you HAVE entered your credentials or other sensitive information:
1. Contact your IT security team immediately — this is an emergency.
2. Change your password immediately from a different, unaffected device.
3. Enable multi-factor authentication on the compromised account if not already enabled.
4. Check your account for unauthorized access, changes, or activity.
5. If financial information was compromised, contact your bank or financial institution immediately.
6. Monitor your credit report for signs of identity theft.

### If you opened an attachment:
1. Disconnect your device from the network immediately (unplug the network cable or disable Wi-Fi).
2. Contact your IT security team and inform them that you may have malware on your device.
3. Do not use the device until it has been examined and cleared by IT security.

## Creating Strong Habits to Resist Phishing

### Slow Down
Phishing emails are designed to make you act quickly without thinking. Developing the habit of pausing before clicking any link or opening any attachment significantly reduces your risk.

### Verify Independently
When you receive an unexpected request — especially involving money, credentials, or sensitive information — verify it through an independent channel. Call the person or organization using a phone number you already have, not one provided in the email.

### Use Password Managers and MFA
Using a password manager ensures you have unique passwords for every account, so a single compromised password does not give attackers access to all your accounts. Enabling multi-factor authentication means that even if attackers obtain your password, they cannot access your account without the second factor.

### Keep Software Updated
Many phishing attacks deliver malware that exploits vulnerabilities in outdated software. Keeping your operating system, browser, and applications updated reduces your exposure to these attacks.

### Report Everything Suspicious
Reporting suspicious emails — even ones you are not sure about — helps your IT security team identify and block phishing campaigns before other employees are affected. There is no penalty for reporting a legitimate email as suspicious.

## Recognizing Targeted Spear Phishing

Unlike generic phishing emails, spear phishing emails are personalized using information about you gathered from social media, company websites, or previous data breaches. They may:
- Address you by name and reference your specific role or department
- Mention colleagues, projects, or events that you are involved in
- Appear to come from your manager, IT department, or a known business partner
- Reference recent company news or events to appear timely and relevant

Because spear phishing emails are more convincing, the same verification principles apply but are even more important. Never assume an email is legitimate simply because it contains accurate personal information about you.
