# Organizational Phishing Incident Response Procedures

## Purpose and Scope

This document defines the procedures that organizations should follow when a phishing email is detected, reported, or suspected. It covers the roles and responsibilities of users, IT security teams, and management in responding to phishing incidents, as well as guidance on containment, investigation, recovery, and reporting.

These procedures apply to all employees, contractors, and third parties who access organizational email systems.

## Phishing Incident Classification

Phishing incidents are classified based on their potential impact and the actions taken by the recipient:

### Level 1 — Phishing Email Received, No Action Taken
- User received a suspected phishing email but did not click any links or open attachments.
- No credentials were entered on any external website.
- Response priority: Low. Log the incident, block the sender, and use the email for security awareness training.

### Level 2 — Link Clicked, No Credentials Entered
- User clicked a link in a suspected phishing email but did not enter any credentials or sensitive information.
- The destination website may have attempted to install malware via drive-by download.
- Response priority: Medium. Scan the user's device for malware, monitor for suspicious activity, and reset passwords as a precaution.

### Level 3 — Credentials Entered or Attachment Opened
- User entered credentials on a phishing website, or opened a malicious attachment.
- Accounts may be compromised and malware may be installed on the device.
- Response priority: High. Immediately isolate the device, reset all affected account passwords, revoke active sessions, and conduct a full forensic investigation.

### Level 4 — Confirmed Account Compromise or Data Breach
- Unauthorized access to organizational systems has been confirmed as a result of a phishing attack.
- Data exfiltration, lateral movement, or malware deployment may have occurred.
- Response priority: Critical. Activate the full incident response plan, involve senior management and legal counsel, and assess regulatory notification requirements.

## Step-by-Step Response Procedures

### Phase 1: Detection and Reporting (0-1 Hour)

1. **User reports suspicious email** via the designated reporting channel (report button, dedicated email address, or helpdesk ticket).
2. **IT security team acknowledges receipt** of the report within 30 minutes during business hours.
3. **Initial triage** is performed to classify the incident level based on user actions taken.
4. **Preserve the original email** with full headers for forensic analysis. Do not delete or forward the email from the user's mailbox without preserving a copy.
5. **Identify all recipients** of the phishing email within the organization using email gateway logs.

### Phase 2: Containment (1-4 Hours)

1. **Block the malicious sender domain** and all associated email addresses at the email gateway.
2. **Block malicious URLs** identified in the phishing email at the web proxy and DNS filtering layers.
3. **Recall or quarantine** the phishing email from all recipient mailboxes where technically possible.
4. **Isolate affected devices** from the network if the user opened an attachment or if malware is suspected.
5. **Disable compromised accounts** temporarily if credentials are believed to have been captured.
6. **Notify affected users** of the phishing campaign with clear guidance on actions to take.

### Phase 3: Investigation (4-24 Hours)

1. **Analyze email headers** to identify the origin of the phishing campaign.
2. **Examine the phishing website** (in a sandbox environment) to understand the attacker's objectives.
3. **Review access logs** for compromised accounts to identify any unauthorized access.
4. **Scan affected devices** for malware using endpoint detection and response (EDR) tools.
5. **Determine the scope** of any data exposure or exfiltration.
6. **Identify indicators of compromise (IoCs)** for use in threat hunting across the organization.

### Phase 4: Recovery (24-72 Hours)

1. **Reset passwords** for all confirmed or suspected compromised accounts.
2. **Revoke and reissue** authentication tokens, API keys, and certificates that may have been exposed.
3. **Remediate malware** on affected devices through reimaging or targeted removal.
4. **Restore data** from backups if ransomware or destructive malware was deployed.
5. **Re-enable accounts** once passwords have been reset and devices have been verified clean.
6. **Verify the integrity** of critical systems and data following the incident.

### Phase 5: Post-Incident Review

1. **Document the incident** in the organization's incident register with a full timeline of events.
2. **Conduct a lessons learned review** to identify gaps in detection, response, or prevention.
3. **Update security controls** based on lessons learned (e.g., new email filtering rules, enhanced training topics).
4. **Share threat intelligence** with relevant partners, information sharing organizations, or law enforcement where appropriate.
5. **Report to regulatory authorities** if required under applicable data protection regulations.

## Roles and Responsibilities

### End Users
- Report suspicious emails immediately without clicking links or opening attachments.
- Follow IT security team instructions promptly during an active incident.
- Complete mandatory phishing awareness training.
- Do not discuss details of a suspected incident on personal devices or external platforms.

### IT Helpdesk
- Acknowledge phishing reports promptly and escalate to the security team.
- Assist users with password resets and device scanning.
- Document all reported incidents.

### IT Security Team
- Lead the investigation and coordinate the response.
- Make decisions about containment measures and communicate with affected users.
- Maintain the organization's threat intelligence and indicator blocking lists.

### Management and Legal Counsel
- Make decisions about regulatory notification and law enforcement involvement.
- Approve communications to customers, partners, or the public about incidents.
- Ensure adequate resources are available for incident response.

## Regulatory Notification Requirements

### GDPR (General Data Protection Regulation)
Under GDPR, personal data breaches must be reported to the relevant supervisory authority within 72 hours of becoming aware of the breach, where feasible. If the breach is likely to result in a high risk to individuals' rights and freedoms, affected individuals must also be notified without undue delay.

### Bahrain Personal Data Protection Law (PDPL)
Organizations operating in Bahrain must notify the Personal Data Protection Authority of data breaches involving personal data. The notification must be made promptly and must include details of the nature of the breach, the data affected, and the measures taken to address it.

### PCI DSS
Organizations that handle payment card data must report security incidents that may affect cardholder data to their acquiring bank and the relevant card brands.

## Phishing Simulation and Training Program

Organizations should conduct regular simulated phishing exercises to:
- Measure the percentage of users who click on simulated phishing links (click rate).
- Identify users who require additional targeted training.
- Track improvement in user resilience over time.
- Test the effectiveness of technical controls such as email filtering.

A typical phishing simulation program includes:
- Monthly or quarterly simulated phishing campaigns using realistic templates.
- Immediate just-in-time training for users who click on simulation links.
- Annual comprehensive phishing awareness training for all staff.
- Specialized training for high-risk roles such as finance, HR, and executives.
