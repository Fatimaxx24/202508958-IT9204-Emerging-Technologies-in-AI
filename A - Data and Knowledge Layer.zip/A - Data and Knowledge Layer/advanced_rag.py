"""
Part I - Extra Challenging Work
Advanced RAG: Hybrid BM25 + Vector Search with CrossEncoder Reranking
Based on Lab 1.5 techniques taught in IT9204.
"""

import os
import re
import glob
from pathlib import Path
from dotenv import load_dotenv
from openai import AzureOpenAI

load_dotenv(dotenv_path=Path(__file__).parent.parent / "E - System Integration" / ".env")

OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
OPENAI_KEY      = os.getenv("AZURE_OPENAI_API_KEY")
OPENAI_VERSION  = os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview")
EMBED_DEPLOYMENT = os.getenv("AZURE_EMBED_DEPLOYMENT", "text-embedding-3-small")

openai_client = AzureOpenAI(
    azure_endpoint=OPENAI_ENDPOINT,
    api_key=OPENAI_KEY,
    api_version=OPENAI_VERSION
)

# ── Load documents ────────────────────────────────────────────────────────────

def load_documents(docs_folder: str) -> list[dict]:
    """Load all .md files and split into chunks."""
    doc_paths = glob.glob(os.path.join(docs_folder, "*.md"))
    documents = []
    for path in doc_paths:
        source = Path(path).stem
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
        text_clean = re.sub(r"[#*`|_\-]+", " ", text)
        text_clean = re.sub(r"\s+", " ", text_clean).strip()
        words  = text_clean.split()
        chunks = []
        start  = 0
        while start < len(words):
            chunk = " ".join(words[start:start+300])
            chunks.append({"content": chunk, "source": source})
            start += 250
        documents.extend(chunks)
    return documents


# ── BM25 retrieval ────────────────────────────────────────────────────────────

def bm25_retrieve(query: str, documents: list[dict], top_k: int = 5) -> list[dict]:
    """BM25 keyword-based retrieval."""
    from rank_bm25 import BM25Okapi
    tokenized_corpus = [doc["content"].lower().split() for doc in documents]
    bm25 = BM25Okapi(tokenized_corpus)
    tokenized_query  = query.lower().split()
    scores = bm25.get_scores(tokenized_query)
    top_indices = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:top_k]
    return [
        {**documents[i], "bm25_score": float(scores[i]), "retrieval": "bm25"}
        for i in top_indices
    ]


# ── Vector retrieval ──────────────────────────────────────────────────────────

def vector_retrieve(query: str, documents: list[dict], top_k: int = 5) -> list[dict]:
    """Vector similarity retrieval using Azure OpenAI embeddings."""
    import numpy as np

    # Embed query
    q_embedding = openai_client.embeddings.create(
        input=[query], model=EMBED_DEPLOYMENT
    ).data[0].embedding
    q_vec = np.array(q_embedding)

    # Embed all documents
    contents = [doc["content"] for doc in documents]
    batch_size = 16
    all_embeddings = []
    for i in range(0, len(contents), batch_size):
        batch = contents[i:i+batch_size]
        response = openai_client.embeddings.create(input=batch, model=EMBED_DEPLOYMENT)
        all_embeddings.extend([item.embedding for item in response.data])

    # Cosine similarity
    scores = []
    for emb in all_embeddings:
        d_vec  = np.array(emb)
        cosine = float(np.dot(q_vec, d_vec) / (np.linalg.norm(q_vec) * np.linalg.norm(d_vec)))
        scores.append(cosine)

    top_indices = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:top_k]
    return [
        {**documents[i], "vector_score": scores[i], "retrieval": "vector"}
        for i in top_indices
    ]


# ── Hybrid retrieval ──────────────────────────────────────────────────────────

def hybrid_retrieve(query: str, documents: list[dict], top_k: int = 5) -> list[dict]:
    """
    Hybrid BM25 + Vector retrieval with Reciprocal Rank Fusion (RRF).
    Combines keyword and semantic search for better coverage.
    """
    bm25_results   = bm25_retrieve(query, documents, top_k=top_k*2)
    vector_results = vector_retrieve(query, documents, top_k=top_k*2)

    # Reciprocal Rank Fusion
    rrf_scores = {}
    k = 60  # RRF constant

    for rank, doc in enumerate(bm25_results):
        key = doc["content"][:100]
        rrf_scores[key] = rrf_scores.get(key, {"doc": doc, "score": 0})
        rrf_scores[key]["score"] += 1 / (k + rank + 1)

    for rank, doc in enumerate(vector_results):
        key = doc["content"][:100]
        if key not in rrf_scores:
            rrf_scores[key] = {"doc": doc, "score": 0}
        rrf_scores[key]["score"] += 1 / (k + rank + 1)

    # Sort by RRF score
    sorted_results = sorted(rrf_scores.values(), key=lambda x: x["score"], reverse=True)
    return [
        {**item["doc"], "rrf_score": item["score"], "retrieval": "hybrid"}
        for item in sorted_results[:top_k]
    ]


# ── CrossEncoder reranking ────────────────────────────────────────────────────

def rerank_with_crossencoder(query: str, candidates: list[dict], top_k: int = 3) -> list[dict]:
    """
    Rerank candidates using CrossEncoder for more accurate relevance scoring.
    Uses sentence-transformers CrossEncoder model.
    """
    from sentence_transformers import CrossEncoder
    model = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")

    pairs  = [[query, doc["content"]] for doc in candidates]
    scores = model.predict(pairs)

    for doc, score in zip(candidates, scores):
        doc["rerank_score"] = float(score)

    reranked = sorted(candidates, key=lambda x: x["rerank_score"], reverse=True)
    return reranked[:top_k]


# ── Full advanced RAG pipeline ────────────────────────────────────────────────

def advanced_retrieve(query: str, docs_folder: str, top_k: int = 3) -> list[dict]:
    """
    Full advanced RAG pipeline:
    1. Hybrid retrieval (BM25 + Vector)
    2. CrossEncoder reranking
    Returns top_k most relevant chunks.
    """
    documents  = load_documents(docs_folder)
    candidates = hybrid_retrieve(query, documents, top_k=top_k*3)
    reranked   = rerank_with_crossencoder(query, candidates, top_k=top_k)
    return reranked


# ── Comparison test ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    DOCS_FOLDER = str(Path(__file__).parent / "RAG Documents")
    documents   = load_documents(DOCS_FOLDER)

    test_queries = [
        "what are the signs of a phishing email",
        "how to respond when credentials are stolen",
        "email authentication SPF DKIM DMARC",
    ]

    print("=" * 65)
    print("  ADVANCED RAG — Hybrid Search + CrossEncoder Reranking")
    print("  Part I: Extra Challenging Work")
    print("=" * 65)

    for query in test_queries:
        print(f"\nQuery: '{query}'")
        print("-" * 50)

        # Basic vector only
        from rag_pipeline import retrieve_documents
        basic = retrieve_documents(query, top_k=3)
        print("Basic Vector Search:")
        for r in basic:
            print(f"  [{r['source']}] score={r['score']:.4f} | {r['content'][:80]}...")

        # Advanced hybrid + reranking
        print("\nAdvanced Hybrid + Reranking:")
        advanced = advanced_retrieve(query, DOCS_FOLDER, top_k=3)
        for r in advanced:
            print(f"  [{r['source']}] rerank={r['rerank_score']:.4f} | {r['content'][:80]}...")